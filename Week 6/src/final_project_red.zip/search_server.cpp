#include "search_server.h"
#include "iterator_range.h"
#include <numeric>
#include <algorithm>
#include <iterator>
#include <sstream>
#include <iostream>
#include <iterator>

vector<string> SplitIntoWords(const string& line) {
  istringstream words_input(line);
  return {make_move_iterator(istream_iterator<string>(words_input)),
	  make_move_iterator(istream_iterator<string>())};
}

InvertedIndex::InvertedIndex(istream& document_input) {
	// max number of words

	string line;
	while(getline(document_input, line)) {
		++num_docs;
		size_t docid = num_docs - 1;

		for(string& word : SplitIntoWords(line)) {
			auto& docid_count = inv_index[word];

			if(!docid_count.empty() && docid_count.back().first == docid) {
				++docid_count.back().second;
			} else {
				docid_count.emplace_back(docid, 1);
			}

		}
	}
}

const vector<pair<size_t, size_t>> InvertedIndex::Lookup(const string& word) const {
	if (const auto it = inv_index.find(word); it != inv_index.end()) {
		return it->second;
	}
	static const vector<pair<size_t, size_t>> result;
	return result;
}



SearchServer::SearchServer(istream& document_input)
	: index(InvertedIndex(document_input)) {
}

void UpdateDocumentBaseHelper(istream& document_input, Synchronized<InvertedIndex>& index) {
	InvertedIndex new_index(document_input);
	swap(index.GetAccess().ref_to_value, new_index);
}

void AddQueriesStreamHelper(istream& query_input,
		ostream& search_results_output, Synchronized<InvertedIndex>& index) {
    vector<size_t> ids_num;
    vector<int64_t> ids;

	string line;
	while(getline(query_input, line))
	{
		const auto words = SplitIntoWords(line);

		auto access = index.GetAccess();
		const size_t docs_count = access.ref_to_value.GetDocsCount();
		ids_num.assign(docs_count, 0);
		ids.resize(docs_count);

		auto& index = access.ref_to_value;
		for (const auto& word : words)
		{
			for (const auto& [doc_id, hit_count] : index.Lookup(word))
			{
				ids_num[doc_id] += hit_count;
			}
		}

		iota(ids.begin(), ids.end(), 0);

	    partial_sort(std::begin(ids),  Head(ids.begin(), ids.end(),
	    		ids.size(), 5).end(), std::end(ids),
			[&ids_num](int64_t lhs, int64_t rhs)
		{
			return make_pair(ids_num[lhs], -lhs) > make_pair(ids_num[rhs], -rhs);
		});

		search_results_output << line << ':';

	    for (size_t doc_id :  Head(ids.begin(), ids.end(), ids.size(), 5))
		{
			const size_t hit_count = ids_num[doc_id];
			if (hit_count == 0)
			{
				break;
			}

			search_results_output << " {" << "docid: " << doc_id << ", " << "hitcount: " << hit_count << '}';
		}

	    search_results_output << '\n';
	}
}

void SearchServer::UpdateDocumentBase(istream& document_input) {
	UpdateDocumentBaseHelper(document_input, index);
}


void SearchServer::AddQueriesStream(istream& query_input,
		ostream& search_results_output) {
	AddQueriesStreamHelper(query_input, search_results_output, index);
}


/*
void SearchServer::AddQueriesStream(istream& query_input,
		ostream& search_results_output) {
	// AddQueriesStreamHelper(query_input, search_results_output, index);

    auto future = [&query_input, &search_results_output, this] {
        size_t docs_num;
        {
        	docs_num = index.GetAccess().ref_to_value.GetDocsCount();
        }
        vector<size_t> docid_count(docs_num);

        for (string current_query; getline(query_input, current_query); ) {
            for(const auto& word: SplitIntoWords(current_query)) {
                for(const auto& [docid, qty] : index.GetAccess().ref_to_value.Lookup(word)) {
                    docid_count[docid] += qty;
                }
            }

            vector<pair<size_t, size_t>> search_results(docid_count.size());
            for(size_t i = 0, I = search_results.size(); i < I; ++i) {
                search_results[i] = {i, docid_count[i]};
            }

            partial_sort(begin(search_results), Head(search_results.begin(), search_results.end(),
            		search_results.size(), 5).end(), end(search_results),
                         [](const pair<size_t, size_t>& lhs, const pair<size_t, size_t>& rhs) {
                int64_t lhs_docid = lhs.first;
                int64_t rhs_docid = rhs.first;
                return make_pair(lhs.second, -lhs_docid) > make_pair(rhs.second, -rhs_docid);
            });

            search_results_output << current_query << ':';
            for (const auto& [docid, count] : Head(search_results.begin(), search_results.end(),
            		search_results.size(), 5)) {
                if(count == 0) {
                    break;
                }

                search_results_output << " {"
                                      << "docid: " << docid << ", "
                                      << "hitcount: " << count << '}';
            }
            search_results_output << '\n';

            fill(begin(docid_count), end(docid_count), 0);
        }
    };

    futures_.push_back(async(future));
}
*/
