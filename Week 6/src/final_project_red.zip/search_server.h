#pragma once
#include "synchronized.h"
#include <istream>
#include <ostream>
#include <set>
#include <list>
#include <vector>
#include <unordered_map>
#include <map>
#include <future>
#include <string>
using namespace std;

class InvertedIndex {
public:
  InvertedIndex() = default;
  explicit InvertedIndex(istream& document_input);
  const vector<pair<size_t, size_t>> Lookup(const string& word) const;

  size_t GetDocsCount() const {
    return num_docs;
  }

private:
  size_t num_docs = 0;
  // each pair represents docid and num of occurences of given string.
  unordered_map<string, vector<pair<size_t, size_t>>> inv_index;
};

class SearchServer {
public:
  SearchServer() = default;
  explicit SearchServer(istream& document_input);
  void UpdateDocumentBase(istream& document_input);
  void AddQueriesStream(istream& query_input, ostream& search_results_output);

private:
  Synchronized<InvertedIndex> index;
};
